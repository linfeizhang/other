1.1.7 Release notes (2016-04-19)
============================================================

* Add PYLoadingOption
* Add PYNoDataLoadingOption
* Update the PYAxis
* Add some method for PYEchartsView

1.1.6 Release notes (2016-04-12)
=============================================================

### Enhancements 

* Add PYSplitArea
* Add some missing properties 

1.1.5 Release notes (2016-04-07)
=============================================================

### Enhancements

* Add Radar and Map Demos
* Replace js files and support all echarts types
* Add PYZoomEchartsView



