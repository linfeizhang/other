This is a custom component for the echarts.

# iOS- Echarts - 将ECharts封装成iOS控件
本项目是将百度的ECharts工具封装成对应的iOS的控件，并且将其中javascript的属性封装成对应的对象。方便程序员在编写程序的过程中更加关注OC的代码，避免在使用百度的ECharts工具的过程中过多的关注javascript语法和与javascript之间的交互。

#Echarts信息
[Echarts Github地址](https://github.com/ecomfe/echarts)

[Echarts 官网(中文)](http://echarts.baidu.com/index.html)

[Echarts WebSite(English)](http://echarts.baidu.com/index-en.html)
