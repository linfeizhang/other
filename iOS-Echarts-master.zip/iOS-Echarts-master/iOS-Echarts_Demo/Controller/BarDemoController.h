//
//  BarDemoControllerViewController.h
//  iOS-Echarts
//
//  Created by Pluto-Y on 15/9/27.
//  Copyright © 2015年 pluto-y. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PYEchartsView.h"

@interface BarDemoController : UIViewController

@property (nonatomic, weak) IBOutlet PYEchartsView *kEchartView;

@end
