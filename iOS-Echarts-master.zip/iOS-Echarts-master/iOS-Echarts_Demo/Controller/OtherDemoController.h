//
//  OtherDemoController.h
//  iOS-Echarts
//
//  Created by Pluto Y on 16/4/15.
//  Copyright © 2016年 pluto-y. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PYEchartsView.h"

@interface OtherDemoController : UIViewController

@property (nonatomic, weak) IBOutlet PYEchartsView *yEchartsView;

@end
