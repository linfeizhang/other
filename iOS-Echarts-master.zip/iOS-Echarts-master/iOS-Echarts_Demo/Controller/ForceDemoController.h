//
//  ForceDemoController.h
//  iOS-Echarts
//
//  Created by Pluto Y on 7/22/16.
//  Copyright © 2016 pluto-y. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PYEchartsView.h"

@interface ForceDemoController : UIViewController

@property (nonatomic, weak) IBOutlet PYEchartsView *kEchartView;

@end
