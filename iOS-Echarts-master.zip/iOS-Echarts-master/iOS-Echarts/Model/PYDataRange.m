//
//  PYDataRange.m
//  iOS-Echarts
//
//  Created by Pluto-Y on 15/11/23.
//  Copyright © 2015年 pluto-y. All rights reserved.
//

#import "PYDataRange.h"
#import "PYColor.h"

@implementation PYDataRange

- (instancetype)init
{
    self = [super init];
    if (self) {
        _show = true;
    }
    return self;
}

@end
