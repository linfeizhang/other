//
//  NSString+triming.h
//  映翰通设备云
//
//  Created by zhanglf on 16/4/15.
//  Copyright © 2016年 zhanglf. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (triming)
- (NSString *)triming;
@end
